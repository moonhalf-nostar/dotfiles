{- this is a comment block -}

xs = [1, 2, 3]
ps = [(1, 2), (3, 1 / 4)]

