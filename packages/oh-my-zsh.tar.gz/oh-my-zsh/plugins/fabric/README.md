# Fabric

This plugin provides completion for [Fabric](https://www.fabfile.org/).

To use it add fabric to the plugins array in your zshrc file.

```zsh
plugins=(... fabric)
```
