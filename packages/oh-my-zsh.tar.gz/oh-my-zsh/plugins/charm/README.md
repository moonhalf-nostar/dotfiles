# Charm plugin

This plugin adds completion for the [charm](https://github.com/charmbracelet/charm) CLI.

To use it, add `charm` to the plugins array in your zshrc file:

```zsh
plugins=(... charm)
```
